Action()
{

	web_url("newtours.demoaut.com", 
		"URL=http://newtours.demoaut.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("login");

	web_submit_form("login.php", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		"Name=userName", "Value=mercury", ENDITEM, 
		"Name=password", "Value=mercury", ENDITEM, 
		"Name=login.x", "Value=0", ENDITEM, 
		"Name=login.y", "Value=0", ENDITEM, 
		EXTRARES, 
		"Url=/classes/calendar/showCalendar.class", "Referer=", ENDITEM, 
		"Url=/classes/calendar/CalSelect.class", "Referer=", ENDITEM, 
		"Url=/classes/calendar/Calendar.class", "Referer=", ENDITEM, 
		"Url=/classes/calendar/showCalendar$SymAction.class", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_start_transaction("FindFlight");

	web_submit_form("mercuryreservation2.php", 
		"Snapshot=t3.inf", 
		ITEMDATA, 
		"Name=tripType", "Value=roundtrip", ENDITEM, 
		"Name=passCount", "Value=1", ENDITEM, 
		"Name=fromPort", "Value=London", ENDITEM, 
		"Name=fromMonth", "Value=July", ENDITEM, 
		"Name=fromDay", "Value=1", ENDITEM, 
		"Name=toPort", "Value=New York", ENDITEM, 
		"Name=toMonth", "Value=July", ENDITEM, 
		"Name=toDay", "Value=1", ENDITEM, 
		"Name=servClass", "Value=First", ENDITEM, 
		"Name=airline", "Value=No Preference", ENDITEM, 
		"Name=findFlights.x", "Value=51", ENDITEM, 
		"Name=findFlights.y", "Value=12", ENDITEM, 
		LAST);

	web_custom_request("gtssl-ocsp.geotrust.com", 
		"URL=http://gtssl-ocsp.geotrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0D0B0@0>0<0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\x19\\x89\\xFD\\x92/`\\xDCkf,3\\x96p\\xA9\\x8F*\\x92x\\x91\\xB9\\x04\\x14v\\xB8M\\xF3DX\\xC2 z\\x8CF%\\xCE\\xEEu\\xFD\\xE5\\xAB\\xC4w\\x02\\x03\\x03\\x14[", 
		EXTRARES, 
		"Url=https://javadl-esd-secure.oracle.com:8080/update/securitypack.jar", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	web_custom_request("ocsp.verisign.com", 
		"URL=http://ocsp.verisign.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14H\\xB7dI\\xF3\\xD5\\xFE\\xFA\\x113\\xAA\\x80^B\\x0F\\x0F\\xCAd6Q\\x04\\x14\\x00\\xD8ZL%\\xC1\"\\xE5\\x8B1\\xEFm\\xBA\\xF3\\xCC_)\\xF1\ra\\x02\\x10%\\x0C\\xE8\\xE00a.\\x9F+\\x89\\xF7\\x05M|\\xF8\\xFD", 
		LAST);

	web_custom_request("ocsp.verisign.com_2", 
		"URL=http://ocsp.verisign.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\xB9\\xE9\\xB2\\x87\\x02\\x85\\x03\\xF8\\xEC\\xA5\\xFBB\\xE1>\\x0FI\\xC7$&\\xE2\\x04\\x14\\x7F\\xD3e\\xA7\\xC2\\xDD\\xEC\\xBB\\xF00\t\\xF3C9\\xFA\\x02\\xAF313\\x02\\x10R\\x00\\xE5\\xAA%V\\xFC\\x1A\\x86\\xED\\x96\\xC9\\xD4K3\\xC7", 
		LAST);

	web_custom_request("sf.symcd.com", 
		"URL=http://sf.symcd.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\xD2\\xA9\\x93\\x06\\xE4\\xCF\\x13\\x03\\xDA\\xDD\\xCEF\\xC2\\x9C\\xDC.0\\x07yV\\x04\\x14\\xCF\\x99\\xA9\\xEA{&\\xF4K\\xC9\\x8E\\x8F\\xD7\\xF0\\x05&\\xEF\\xE3\\xD2\\xA7\\x9D\\x02\\x10&\\xF2\\xECv\"\\xDDJ\\xB7A\\x92\\x08<\\x04]\\xC4u", 
		LAST);

	lr_end_transaction("FindFlight",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("SelectFlight");

	web_submit_data("mercurypurchase.php", 
		"Action=http://newtours.demoaut.com/mercurypurchase.php", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://newtours.demoaut.com/mercuryreservation2.php", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value=London", ENDITEM, 
		"Name=toPort", "Value=New York", ENDITEM, 
		"Name=passCount", "Value=1", ENDITEM, 
		"Name=toDay", "Value=1", ENDITEM, 
		"Name=toMonth", "Value=7", ENDITEM, 
		"Name=fromDay", "Value=1", ENDITEM, 
		"Name=fromMonth", "Value=7", ENDITEM, 
		"Name=servClass", "Value=First", ENDITEM, 
		"Name=outFlight", "Value=Blue Skies Airlines$360$270$5:03", ENDITEM, 
		"Name=inFlight", "Value=Blue Skies Airlines$630$270$12:23", ENDITEM, 
		"Name=reserveFlights.x", "Value=55", ENDITEM, 
		"Name=reserveFlights.y", "Value=12", ENDITEM, 
		LAST);

	lr_end_transaction("SelectFlight",LR_AUTO);

	lr_think_time(42);

	lr_start_transaction("buyFlight");

	web_submit_form("mercurypurchase2.php", 
		"Snapshot=t9.inf", 
		ITEMDATA, 
		"Name=passFirst0", "Value=Jojo", ENDITEM, 
		"Name=passLast0", "Value=Bean", ENDITEM, 
		"Name=pass.0.meal", "Value=No preference", ENDITEM, 
		"Name=creditCard", "Value=American Express", ENDITEM, 
		"Name=creditnumber", "Value=12345678", ENDITEM, 
		"Name=cc_exp_dt_mn", "Value=None", ENDITEM, 
		"Name=cc_exp_dt_yr", "Value=None", ENDITEM, 
		"Name=cc_frst_name", "Value=", ENDITEM, 
		"Name=cc_mid_name", "Value=", ENDITEM, 
		"Name=cc_last_name", "Value=", ENDITEM, 
		"Name=billAddress1", "Value=1325 Borregas Ave.", ENDITEM, 
		"Name=billAddress2", "Value=", ENDITEM, 
		"Name=billCity", "Value=Sunnyvale", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=94089", ENDITEM, 
		"Name=billCountry", "Value=UNITED STATES", ENDITEM, 
		"Name=delAddress1", "Value=1325 Borregas Ave.", ENDITEM, 
		"Name=delAddress2", "Value=", ENDITEM, 
		"Name=delCity", "Value=Sunnyvale", ENDITEM, 
		"Name=delState", "Value=CA", ENDITEM, 
		"Name=delZip", "Value=94089", ENDITEM, 
		"Name=delCountry", "Value=UNITED STATES", ENDITEM, 
		"Name=buyFlights.x", "Value=79", ENDITEM, 
		"Name=buyFlights.y", "Value=13", ENDITEM, 
		LAST);

	lr_end_transaction("buyFlight",LR_AUTO);

	lr_start_transaction("Signoff)");

	web_link("SIGN-OFF", 
		"Text=SIGN-OFF", 
		"Snapshot=t10.inf", 
		LAST);

	lr_end_transaction("Signoff)",LR_AUTO);

	return 0;
}