Action()
{

	web_url("newtours.demoaut.com", 
		"URL=http://newtours.demoaut.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Cruises");

	web_link("Cruises", 
		"Text=Cruises", 
		"Snapshot=t2.inf", 
		LAST);

	lr_end_transaction("Cruises",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Support");

	web_link("Hotels", 
		"Text=Hotels", 
		"Snapshot=t3.inf", 
		LAST);

	lr_end_transaction("Support",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("Contact");

	web_link("Hotels_2", 
		"Text=Hotels", 
		"Snapshot=t4.inf", 
		LAST);

	lr_end_transaction("Contact",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("BackHome");

	web_link("Home", 
		"Text=Home", 
		"Snapshot=t5.inf", 
		LAST);

	lr_end_transaction("BackHome",LR_AUTO);

	lr_think_time(10);

	return 0;
}